#!/bin/bash
q=1
while [ $q -le 5 ]
do
sleep 2
ff="$(grep -e 'scan consume' /root/miner/log/miner.log.log | tail -n1)"
ffv=${ff##*scan consume=}
fff=${ffv% scan time*}
echo "$fff" > miner/log/1.log
done 






