# !/bin/bash
echo "Vvod id :"
read nd
echo "kluch = '$nd' ustanovlen"
sed -i "s/`head -5 .config/rclone/rclone.conf | tail -1 `/team_drive = $nd/" .config/rclone/rclone.conf