#!/usr/bin/expect -f 
set pid [lindex $argv 0]
set skan1 [lindex $argv 1]
spawn scanmem $pid
sleep 5
# expect ">"
send -- "$skan1\r"
set op $skan1
while { $skan1 == $op } {
# puts "\noshodaem smenu $skan1"
set op1 [open miner/log/1.log]
set op [read $op1]
close $op1
set timeout 3
sleep 2
# log_user 0
# spawn ./33.sh 
# log_user 1
}
set op2 [open /root/miner/log/1.log ]
set skan2 [read $op2]
send -- "$skan2\r"
close $op2
sleep 2
send -- "list\r"
sleep 2
expect eof