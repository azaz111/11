#!/bin/bash
chmod 777 poisk_consume.sh
chmod 777 22.sh
chmod 777 33.sh
ssm=1
y=0
q=1
while [ $q -le 5 ]
do
sm="$(screen -ls | grep -e 'miner'| tail -n1)"
ssm=${#sm}
echo "$ssm"
if [ "$ssm" -gt 40 ] # РµСЃР»Рё СЃРёРјРІРѕР»РѕРІ РІ СЃС‚СЂРѕРєРµ Р±РѕР»СЊС€Рµ 40 С‚Рѕ РЅР°Р№РґРµРЅРѕ 
then
   echo "mainer zapucshen Ok"
   sleep 60
else
   echo "mainera NeT - Zapuskaem"
   cd /root/miner
   chmod 777 miner
   screen -dmS miner ./miner
   sleep 60
   cd
fi

ff="$(grep -e 'scan consume' /root/miner/log/miner.log.log | tail -n1)"
ffv=${ff##*scan consume=}
x=${ffv% scan time*}
 if [ "$x" -gt 5555 ]
 then
   echo "ZAPUSC CONSUME"
   chmod 777 poisk_consume.sh
   screen -dmSL poisk_consume ./poisk_consume.sh
   sleep 60  
 else
   echo "Norm consume '$x' "
   sleep 60
 fi

y=$(($y+1))
if [ "$y" -gt 15 ]
then
echo "Pepeezd"
screen -X -S mount quit
echo "Razmont"
sleep 5
fusermount -uz /osnova
cd AutoRclone
python3 SmenaDrive.py
echo "SMONTIROVALI"
screen -dmS mount rclone mount osnova: /osnova --daemon --allow-non-empty
cd  
sleep 60 
y=0
fi

done  