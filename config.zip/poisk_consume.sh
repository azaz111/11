#!/bin/bash
chmod 777 33.sh
screen -X -S consume quit
screen -dmS sistem33 ./33.sh
rm screenlog.0
sm="$(ps ax | grep -e './miner' | tail -n2 )"
ssm=${sm:0:7}
ssm=$(echo $ssm | sed s/' '//g)
echo "$ssm"
ff="$( grep -e 'scan consume' /root/miner/log/miner.log.log | tail -n1)"
ffv=${ff##*scan consume=}
fff=${ffv% scan time*}
echo "$fff"
echo "$fff" > miner/log/1.log
sleep 4
cd
./22.sh $ssm $fff
sleep 10
cc="$( grep -e '0]' screenlog.0 | tail -n1 )"
sleep 3
scc=${cc##*0\]   }
ssc=${scc:0:10}
echo "$ssc"  # > miner/log/2.log
screen -X -S sistem33 quit
echo -e "#!/bin/bash\nwhile :\ndo\nsleep 2\nscanmem -p $ssm -c'write i32 $ssc 5555; quit';\ndone" > /root/consume.sh
sleep 3
chmod 777 consume.sh
sleep 3
screen -dmS consume ./consume.sh
sleep 20
cd