
import subprocess
import time
import os
from sys import argv



new_grives = service.teamdrives().list(pageSize=100).execute() # Cписок всех дисков
folder_idsm = new_grives.get('teamDrives')



#ls
id = []
name = []


for sps in folder_idsm: 
   name_nd = sps.get('name')
   name.append(name_nd)
   s_iddrive = sps.get('id') 
   id.append(s_iddrive)
#


j = 1


i_dr=0 #cчетчик дисков
inn=0 #cчетчик имен
for i in id:
   if i_dr == 5 :
       j = 253
   if i_dr == 11 :
       j = 506
   #process.wait()
   print(i)
   print(name[inn])
   
   process = subprocess.Popen(['python3', 'copi_drive_st.py', f'{i}', f'{name[inn]}', f'{j}'])
   time.sleep(5)
   inn+=1
   i_dr+=1
#for i in id_spis:
#   process = subprocess.Popen(['python3', 'masshare.py', '-d', f'{i}'])
#   process.wait()