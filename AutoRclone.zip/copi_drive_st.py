from google.oauth2 import service_account
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
import io
from googleapiclient.errors import HttpError
import os
from sys import argv

s_iddrive = argv[1]
print(s_iddrive)
name = argv[2]
print(name)
json_nomber = int(argv[3])
print(json_nomber) 


def createRemoteFolder(service2, folderName, parentID = None):
    # Create a folder on Drive, returns the newely created folders ID 
    print(f'vzghu imya {folderName}')
    body = {'title': folderName,
      'mimeType': "application/vnd.google-apps.folder"
    }
    if parentID:
        body['parents'] = [{'id': parentID}]
    root_folder = service2.files().insert(supportsTeamDrives=True , body = body ).execute() 
    return root_folder['id']

def nev_json_autoriz(json_nomber,SCOPES):
   SERVICE_ACCOUNT_FILE = f'accounts/{json_nomber}.json'
   credentials = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
   service = build('drive', 'v3', credentials=credentials)
   return service

SCOPES = ["https://www.googleapis.com/auth/drive",
          "https://www.googleapis.com/auth/cloud-platform",
          "https://www.googleapis.com/auth/iam"]

credentials = Credentials.from_authorized_user_file('token.json', SCOPES)
service = build('drive', 'v3', credentials=credentials)
service2 = build('drive', 'v2', credentials=credentials)


folder_ids = service.files().list(corpora='drive', 
                                  includeItemsFromAllDrives=True, 
                                  supportsAllDrives=True,
                                  q="mimeType = 'application/vnd.google-apps.folder'", 
                                  driveId=s_iddrive, fields="nextPageToken, files(id,name)").execute() # РЎРїРёСЃРѕРє РїР°РїРѕРє РЅР° РґРёСЃРєРµ
folder_idss = folder_ids.get('files')
folder_ids = folder_idss[0]
folder_id = folder_ids.get('id') # Р°Р№РґРё РїР°РїРєРё СЃ РїР»РѕС‚Р°РјРё
folder_name = folder_ids.get('name') # РРјСЏ РїР°РїРєРё
print(folder_id)
folder_name_n = f'{folder_name}-becap'
print(folder_name_n)

file_ids = service.files().list(corpora='drive',
                                includeItemsFromAllDrives=True,
                                supportsAllDrives=True,
                                driveId=s_iddrive,
                                pageSize=1000, fields="nextPageToken, files(id)").execute() # РџРѕР»СѓСЏР°РµРј СЃРїРёСЃРѕРє РІСЃРµС… С„Р°Р№Р»РѕРІ РЅР° РґРёСЃРєРµ
file_ids = file_ids.get('files')
id_foldnazna=(createRemoteFolder(service2,folder_name_n,s_iddrive)) # РЎРћР·РґР°С‚СЊ РїР°РїРєСѓ СЃ РёРјРµРЅРµРј +Р±РµРєР°Рї
service = nev_json_autoriz(json_nomber,SCOPES)
index_json=1 # РЁР°Рі СЃРјРµРЅС‹
ij=0
for i in file_ids: 
   id = i.get('id') 
   print(f'new file :{id}')
   try:
      if ij == index_json:
         json_nomber=json_nomber+1
         if json_nomber >= 599 :
            json_nomber = 1
            # СЃР±СЂРѕСЃ СЃС‡РµС‚С‡РёРєР° + РЅРѕРІС‹Р№ РґР¶РёСЃРѕРЅ 
         print(f"New J {json_nomber}")      
         service = nev_json_autoriz(json_nomber,SCOPES)
         ij=0
      ij=ij+1
      print('copirovanie')
      new_file = service.files().copy( fileId=id , supportsTeamDrives=True ).execute() # РєРѕРїРёСЂСѓРµРј РІ С†РёРєР»Рµ
      new_file = new_file.get('id')
      print(f'kopia = {new_file} ')
      file = service.files().get(fileId=new_file, supportsAllDrives=True, fields='parents').execute()
      previous_parents = ",".join(file.get('parents')) 
      file = service.files().update(fileId=new_file,
                                    addParents=id_foldnazna,
                                    supportsAllDrives=True, 
                                    removeParents=previous_parents, fields='id, parents').execute()# РїРµСЂРµРјРµС‰Р°РµРј РІ Р±РµРєР°РїРЅСѓСЋ РїР°РїРєСѓ
             
   except HttpError: 
      print('Oshibka ne pustoi') 
print('Vipolnenno')

# python copi_drive.py "5"  # РџСЂРёРјРµСЂ Р·Р°РїСѓСЃРєР° 
# 1 Р”РѕР»Р¶РµРЅ Р±С‹С‚СЊ Р°РІС‚РѕСЂРёР·РѕРІР°РЅ РґР¶РёСЃРѕРЅ С‚РѕРєРµРЅ РІ РїР°РїРєРµ 
# 2 РџР°РїРєР° acounts  РІ РєРѕСЂРЅРµ РєР°С‚Р°Р»РѕРіР° 
# 3 РџРѕР»СЊР·РѕРІР°С‚РµР»Рё РїСЂРёРІСЏР·Р°РЅС‹ Рє РґРёСЃРєСѓ 
# 4 РўРѕР»СЊРєРѕ РѕРґРЅР° РїР°РїРєР° РґР»СЏ Р±РµРєР°РїРїР° РЅР° РґРёСЃРєРµ 
# 5 РџСЂРѕРІРµСЂРёС‚СЊ С‡С‚Рѕ РєРѕСЂР·РёРЅР° РїСѓСЃС‚Р°СЏ РґР»СЏ РєР°Р¶РґРѕРіРѕ РґРёСЃРєР°