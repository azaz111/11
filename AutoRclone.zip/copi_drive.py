from google.oauth2 import service_account
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
import io
from googleapiclient.errors import HttpError
import os
from sys import argv

s_iddrive = argv[1]
json_nomber = argv[2]
print(s_iddrive) 
print(json_nomber) 


def createRemoteFolder(service2, folderName, parentID = None):
    # Create a folder on Drive, returns the newely created folders ID 
    print(f'vzghu imya {folderName}')
    body = {'title': folderName,
      'mimeType': "application/vnd.google-apps.folder"
    }
    if parentID:
        body['parents'] = [{'id': parentID}]
    root_folder = service2.files().insert(supportsTeamDrives=True , body = body ).execute() 
    return root_folder['id']

def nev_json_autoriz(json_nomber,SCOPES):
   SERVICE_ACCOUNT_FILE = f'accounts/{json_nomber}.json'
   credentials = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
   service = build('drive', 'v3', credentials=credentials)
   return service


SCOPES = ["https://www.googleapis.com/auth/drive",
          "https://www.googleapis.com/auth/cloud-platform",
          "https://www.googleapis.com/auth/iam"]

credentials = Credentials.from_authorized_user_file('token.json', SCOPES)
service = build('drive', 'v3', credentials=credentials)
service2 = build('drive', 'v2', credentials=credentials)


folder_ids = service.files().list(corpora='drive', includeItemsFromAllDrives=True, supportsAllDrives=True,q="mimeType = 'application/vnd.google-apps.folder'", driveId=s_iddrive, fields="nextPageToken, files(id,name)").execute()
#определенного диска 
folder_idss = folder_ids.get('files')
folder_ids = folder_idss[0]
folder_id = folder_ids.get('id') # айди папки с плотами
folder_name = folder_ids.get('name') # Имя папки
print(folder_id)
folder_name_n = f'{folder_name}-becap'
print(folder_name_n)

file_ids = service.files().list(corpora='drive', includeItemsFromAllDrives=True, supportsAllDrives=True, driveId=s_iddrive, fields="nextPageToken, files(id)").execute() # Получаем список всех фалов

id_foldnazna=(createRemoteFolder(service2,folder_name_n,s_iddrive)) # СОздать папку с именем +бекап
file_ids = file_ids.get('files')

service = nev_json_autoriz(json_nomber,SCOPES)
index_json=2 # Шаг смены
ij=0
for i in file_ids: 
   id = i.get('id') 
   print(f'new file :{id}')
   try:
      if ij == index_json:
         json_nomber=json_nomber+1
         # сброс счетчика + новый джисон 
         print(f"New J {json_nomber}")      
         service = nev_json_autoriz(json_nomber,SCOPES)
         ij=0
      ij=ij+1
      print('copirovanie')
      new_file = service.files().copy( fileId=id , supportsTeamDrives=True ).execute() # копируем в цикле
      new_file = new_file.get('id')
      print(f'kopia = {new_file} ')
      file = service.files().get(fileId=new_file, supportsAllDrives=True, fields='parents').execute()
      previous_parents = ",".join(file.get('parents')) 
      file = service.files().update(fileId=new_file,addParents=id_foldnazna, supportsAllDrives=True, removeParents=previous_parents, fields='id, parents').execute()# перемещаем в бекапную папку 
      
   except HttpError: 
      print('Oshibka ne pustoi') 
print('Vipolnenno')

# python copi_drive.py 0ANO71xPb-u5DUk9PVA "5"  # Пример запуска 
# 1 Должен быть авторизован джисон токен в папке 
# 2 Папка acounts  в корне каталога 
# 3 Пользователи привязаны к диску 
# 4 Только одна папка для бекаппа на диске 
# 5 ЗАпуск следующего клонирования с полсднего джисона +1