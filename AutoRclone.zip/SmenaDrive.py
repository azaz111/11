from __future__ import print_function
import os.path
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
import os
from random import randint
import subprocess
import argparse
import fileinput
import time
from googleapiclient.errors import HttpError
# If modifying these scopes, delete the file token.json.
SCOPES = ["https://www.googleapis.com/auth/drive",
          "https://www.googleapis.com/auth/cloud-platform",
          "https://www.googleapis.com/auth/iam"]



def main():
    filed_conf_rclone = "/root/.config/rclone/rclone.conf"
    """Shows basic usage of the Drive v3 API.
    Prints the names and ids of the first 10 files the user has access to.
    """
    creds = None
    # The file token.json stores the user's access and refresh tokens, and is
    # created automatically when the authorization flow completes for the first
    # time.
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open('token.json', 'w') as token:
            token.write(creds.to_json())

    service = build('drive', 'v3', credentials=creds)
    
    # РџРѕР»СѓС‡Р°РµРј Р°Р№РґРё С‚РµРєС‰РµРіРѕ РґРёСЃРєР° СЃ РєРѕРЅС„РёРіР°
    fnon = open(filed_conf_rclone, "r") 
    ns = fnon.readlines() # Р—Р°РїРёСЃР°С‚СЊ РїРѕСЃС‚СЂРѕС‡РЅРѕ
    d = 'team_drive'
    for i in ns: 
       if d in i: 
           id_smemi = i.split()[-1] 
    fnon.close()

    print(f'Disk kotorii zamenit : "{id_smemi}"') 
    fnon.close()
    # РЈР·РЅР°РµРј РёРјСЏ РґР»СЏ РєР»РѕРЅР°
    name_p = service.drives().get(driveId=id_smemi).execute() 
    name_zam=name_p['name']   
    
    
    # РЈР·РЅР°РµРј Р°Р№РґРё РїР°РїРєРё СЃ РїР»РѕС‚Р°РјРё
    folder_ids = service.files().list(corpora='drive', includeItemsFromAllDrives=True, supportsAllDrives=True,q="mimeType = 'application/vnd.google-apps.folder'", driveId=id_smemi, fields="nextPageToken, files(id)").execute()
    #РѕРїСЂРµРґРµР»РµРЅРЅРѕРіРѕ РґРёСЃРєР° 
    folder_ids = folder_ids.get('files')
    folder_ids = folder_ids[0]
    folder_id = folder_ids.get('id') # Р°Р№РґРё РїР°РїРєРё СЃ РїР»РѕС‚Р°РјРё
    
    
    # РЎРѕР·РґР°РµРј РґРёСЃРє РґР»СЏ РїРµСЂРµРµР·РґР° СЃ С‚РµРј Р¶Рµ РёРјРµРЅРµРј 
    # Р’С‹РІРѕРґРёРј РІ РїРµСЂРµРјРµРЅРЅСѓСЋ Р°РґРё РЅРѕРІРѕРіРѕ РґРёСЃРєР° Рё РїРёС€РµРј РѕР±СЂР°С‚РЅРѕ РІ РєРѕРЅС„РёРі СЂРєР»РѕРЅР°
    new_grive = service.teamdrives().create(requestId=randint(1,9999999), body={"name":f"{name_zam}"}).execute()
    new_grive_id=new_grive['id']  
    

    
    # РїРѕРґРєР»СЋС‡Р°РµРј РїРѕР»СЊР·РѕРІР°С‚РµР»РµР№ Рє РґРёСЃРєСѓ
    subprocess.Popen(['python3', 'masshare.py', '-d', f'{new_grive_id}'])  # РїРѕРґРєР»СЋС‡Р°РµРј РїРѕР»СЊР·РѕРІР°С‚РµР»РµР№ Рє РґРёСЃРєСѓ
     
    ## РљРѕРїРёСЂСѓРµРј РїР°РїРєСѓ СЃ С„Р°Р№Р»Р°РјРё РЅР° РЅРѕРІС‹Р№ РґРёСЃРє 
    file = service.files().get(fileId=folder_id, supportsAllDrives=True, fields='parents').execute()
    previous_parents = ",".join(file.get('parents')) 
    file = service.files().update(fileId=folder_id,addParents=new_grive_id, supportsAllDrives=True, removeParents=previous_parents, fields='id, parents').execute()
   
  # РїРёС€РµРј РѕР±СЂР°С‚РЅРѕ РІ РєРѕРЅС„РёРі СЂРєР»РѕРЅР°
    for line in fileinput.input(filed_conf_rclone, inplace = 1):      
       line = line.replace(id_smemi,new_grive_id)
       print (line.strip())    

    # РЈРґР°Р»РёС‚СЊ СЃС‚Р°СЂС‹Р№ РґРёСЃРє
    time.sleep(300)
    try:
       service.teamdrives().delete(teamDriveId=id_smemi).execute()
       print('Udalen')
    except HttpError: 
       print('Oshibka ne pustoi dadim esche vremya')  
       time.sleep(300)
       service.teamdrives().delete(teamDriveId=id_smemi).execute()
       print('dolshno viiti')    
     
    
  
       
    print('Vipolnenno') 

if __name__ == '__main__':
    main()