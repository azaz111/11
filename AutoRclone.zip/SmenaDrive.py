from __future__ import print_function
import os.path
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
import os
from random import randint
import subprocess
import argparse
import fileinput
import time
# If modifying these scopes, delete the file token.json.
SCOPES = ["https://www.googleapis.com/auth/drive",
          "https://www.googleapis.com/auth/cloud-platform",
          "https://www.googleapis.com/auth/iam"]



def main():
    filed_conf_rclone = "/root/.config/rclone/rclone.conf"
    """Shows basic usage of the Drive v3 API.
    Prints the names and ids of the first 10 files the user has access to.
    """
    creds = None
    # The file token.json stores the user's access and refresh tokens, and is
    # created automatically when the authorization flow completes for the first
    # time.
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open('token.json', 'w') as token:
            token.write(creds.to_json())

    service = build('drive', 'v3', credentials=creds)
    
    # Получаем айди текщего диска с конфига
    fnon = open(filed_conf_rclone, "r") 
    ns = fnon.readlines() # Записать построчно
    d = 'team_drive'
    for i in ns: 
       if d in i: 
           id_smemi = i.split()[-1] 
    fnon.close()

    print(f'Disk kotorii zamenit : "{id_smemi}"') 
    fnon.close()
    # Узнаем имя для клона
    name_p = service.drives().get(driveId=id_smemi).execute() 
    name_zam=name_p['name']   
    
    
    # Узнаем айди папки с плотами
    folder_ids = service.files().list(corpora='drive', includeItemsFromAllDrives=True, supportsAllDrives=True,q="mimeType = 'application/vnd.google-apps.folder'", driveId=id_smemi, fields="nextPageToken, files(id)").execute()
    #определенного диска 
    folder_ids = folder_ids.get('files')
    folder_ids = folder_ids[0]
    folder_id = folder_ids.get('id') # айди папки с плотами
    
    
    # Создаем диск для переезда с тем же именем 
    # Выводим в переменную ади нового диска и пишем обратно в конфиг рклона
    new_grive = service.teamdrives().create(requestId=randint(1,9999999), body={"name":f"{name_zam}"}).execute()
    new_grive_id=new_grive['id']  
    

    
    # подключаем пользователей к диску
    subprocess.Popen(['python3', 'masshare.py', '-d', f'{new_grive_id}'])  # подключаем пользователей к диску
     
    ## Копируем папку с файлами на новый диск 
    file = service.files().get(fileId=folder_id, supportsAllDrives=True, fields='parents').execute()
    previous_parents = ",".join(file.get('parents')) 
    file = service.files().update(fileId=folder_id,addParents=new_grive_id, supportsAllDrives=True, removeParents=previous_parents, fields='id, parents').execute()
   
  # пишем обратно в конфиг рклона
    for line in fileinput.input(filed_conf_rclone, inplace = 1):      
       line = line.replace(id_smemi,new_grive_id)
       print (line.strip())    

    # Удалить старый диск
    time.sleep(300)
    
    service.teamdrives().delete(teamDriveId=id_smemi).execute() 
    
  
       
    print('Vipolnenno') 

if __name__ == '__main__':
    main()