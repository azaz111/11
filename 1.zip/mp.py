
import subprocess
import time
import os
from sys import argv


process = subprocess.Popen(['python3', 'ls.py'])
process.wait()
#
#ls
id = []
name = []

#

while True:
    print("in Drive :")
    a = input() 
    id.append(a)
    print("in Name :")
    n = input() 
    name.append(n)
    print("Prodolzhim ? : 1-yes , 2-no")
    z = int(input())
    if z == 1:
        pass
    else:
        print("Jsone nomber :")
        j = int(input())
        break     
inn=0
for i in id:
   

   #process.wait()
   print(i)
   print(name[inn])
   
   process = subprocess.Popen(['python3', 'copi_drive_st.py', f'{i}', f'{name[inn]}', f'{j}'])
   time.sleep(5)
   inn+=1

#for i in id_spis:
#   process = subprocess.Popen(['python3', 'masshare.py', '-d', f'{i}'])
#   process.wait()